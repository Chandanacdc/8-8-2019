import { DeliverListComponent } from '../deliverylist/deliverlist.component';
import { AddDeliveryComponent } from '../adddelivery/adddelivery.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { EditComponent } from '../edit/edit.component';
const routes: Routes = [
   {path:'home',component:HomeComponent},
  {path:'add',component:AddDeliveryComponent},
  {path:'view',component:DeliverListComponent},
     {path:'edit',component:EditComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
